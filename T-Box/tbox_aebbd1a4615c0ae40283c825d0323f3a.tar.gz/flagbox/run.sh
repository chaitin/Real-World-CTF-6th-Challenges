#! /bin/sh
nohup /echo_hex &
sleep infinity