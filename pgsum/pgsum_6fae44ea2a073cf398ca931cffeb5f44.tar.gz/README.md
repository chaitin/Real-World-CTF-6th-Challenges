We have added sum support for string to postgresql! Try it out!  
```sql
SELECT
	sum(points)
FROM
	rwctf;
```

Login the database with user `ctf`, password `123qwe!@#QWE`.  
